@echo off
setlocal
pushd "%~dp0"

REM ============================================================================
REM NW Interstellar Angular NF API Testing - Fund Profile Launcher
REM Executes run-collection.js and relies on the same report/mail flow as
REM NW_Interstellar_API_Automation.
REM ============================================================================

echo ============================================================================
echo NW Interstellar Angular NF API Testing Run
echo ============================================================================
echo.
echo Starting all-collection execution with SMTP report notification...
echo.

REM SMTP settings (same pattern as NW_Interstellar_API_Automation)
if not defined SMTP_ENABLED set SMTP_ENABLED=true
if not defined SMTP_HOST set SMTP_HOST=mail-gw.ent.nwie.net
if not defined SMTP_PORT set SMTP_PORT=25
if not defined SMTP_FROM set SMTP_FROM=gunasb@nationwide.com
if not defined SMTP_TO set SMTP_TO=gunasb@nationwide.com
if not defined SMTP_SSL set SMTP_SSL=false
if not defined SMTP_SUBJECT_PREFIX set SMTP_SUBJECT_PREFIX=[NW API Automation]
if not defined SMTP_CC set SMTP_CC=

REM Optional: uncomment if relay requires authentication.
REM set SMTP_USER=your_user@nationwide.com
REM set SMTP_PASS=your_password

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found in PATH.
  echo Install Node.js or add it to PATH, then rerun this launcher.
  popd
  exit /b 1
)

where powershell >nul 2>nul
if errorlevel 1 (
  echo ERROR: PowerShell was not found in PATH.
  popd
  exit /b 1
)

REM Headless mode for scheduler runs.
REM Set RUN_HEADLESS=false to show the PowerShell host window.
if not defined RUN_HEADLESS set RUN_HEADLESS=true

if /I "%RUN_HEADLESS%"=="true" (
  echo Running in headless mode.
  powershell -NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\run-all-collections-scheduled.ps1" -DataFile "ticker.csv" -ArchiveReports true -HideReportSecrets
) else (
  echo Running in visible mode.
  powershell -NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass -File "%~dp0scripts\run-all-collections-scheduled.ps1" -DataFile "ticker.csv" -ArchiveReports true -HideReportSecrets
)
set EXIT_CODE=%ERRORLEVEL%

if not "%EXIT_CODE%"=="0" (
  echo.
  echo Run completed with failing assertions or execution errors. Exit code: %EXIT_CODE%
  echo Reports are generated under reports\.
) else (
  echo.
  echo Run completed successfully.
)

echo.
echo ============================================================================
echo Completed. Check email for HTML/XLSX report attachments.
echo ============================================================================
popd
exit /b %EXIT_CODE%
