const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const newman = require('newman');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const projectRoot = path.resolve(__dirname, '..');
let xlsx;
let nodemailer;
try {
  xlsx = require('xlsx');
} catch (error) {
  xlsx = null;
}
try {
  nodemailer = require('nodemailer');
} catch (error) {
  nodemailer = null;
}

function getArgValue(flag) {
  const index = process.argv.indexOf(flag);
  if (index === -1 || index + 1 >= process.argv.length) {
    return undefined;
  }
  return process.argv[index + 1];
}

function getBooleanArg(flag, defaultValue) {
  const value = getArgValue(flag);
  if (typeof value === 'undefined') {
    return defaultValue;
  }

  const normalized = String(value).toLowerCase();
  return normalized === 'true' || normalized === '1' || normalized === 'yes';
}

function parseBooleanValue(value, defaultValue) {
  if (typeof value === 'undefined' || value === null) {
    return defaultValue;
  }

  const normalized = String(value).trim().toLowerCase();
  if (!normalized) {
    return defaultValue;
  }

  return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'y';
}

function getArgOrEnvValue(flag, envName, defaultValue = '') {
  const argValue = getArgValue(flag);
  if (typeof argValue !== 'undefined' && String(argValue).trim() !== '') {
    return String(argValue).trim();
  }

  const envValue = process.env[envName];
  if (typeof envValue !== 'undefined' && String(envValue).trim() !== '') {
    return String(envValue).trim();
  }

  return defaultValue;
}

function parseRecipients(value) {
  if (!value) {
    return [];
  }

  return String(value)
    .split(/[;,]/)
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
}

function resolveSmtpConfig() {
  const envSecureValue = typeof process.env.SMTP_SECURE !== 'undefined'
    ? process.env.SMTP_SECURE
    : process.env.SMTP_SSL;
  const enabled = parseBooleanValue(
    typeof getArgValue('--smtp-enabled') !== 'undefined' ? getArgValue('--smtp-enabled') : process.env.SMTP_ENABLED,
    false
  );
  const secure = parseBooleanValue(
    typeof getArgValue('--smtp-secure') !== 'undefined' ? getArgValue('--smtp-secure') : envSecureValue,
    false
  );
  const portValue = getArgOrEnvValue('--smtp-port', 'SMTP_PORT', secure ? '465' : '25');
  const parsedPort = Number(portValue);

  return {
    enabled,
    host: getArgOrEnvValue('--smtp-host', 'SMTP_HOST', ''),
    port: Number.isFinite(parsedPort) ? parsedPort : (secure ? 465 : 25),
    secure,
    user: getArgOrEnvValue('--smtp-user', 'SMTP_USER', ''),
    pass: getArgOrEnvValue('--smtp-pass', 'SMTP_PASS', ''),
    from: getArgOrEnvValue('--smtp-from', 'SMTP_FROM', ''),
    to: parseRecipients(getArgOrEnvValue('--smtp-to', 'SMTP_TO', '')),
    cc: parseRecipients(getArgOrEnvValue('--smtp-cc', 'SMTP_CC', '')),
    subjectPrefix: getArgOrEnvValue('--smtp-subject-prefix', 'SMTP_SUBJECT_PREFIX', '[NW API Automation]')
  };
}

function isSmtpConfigValid(config) {
  return !!(
    config
    && config.enabled
    && config.host
    && config.from
    && Array.isArray(config.to)
    && config.to.length > 0
  );
}

function buildSmtpSubject(config, statusLabel, title) {
  const prefix = config && config.subjectPrefix ? config.subjectPrefix : '[NW API Automation]';
  return `${prefix} ${statusLabel} | ${title}`;
}

function buildSmtpText(lines) {
  return `${lines.filter((line) => typeof line !== 'undefined' && line !== null).join('\n')}\n`;
}

function buildSmtpHtml(title, sections) {
  const renderedSections = (Array.isArray(sections) ? sections : [])
    .filter((section) => section && section.heading)
    .map((section) => {
      const rows = (Array.isArray(section.rows) ? section.rows : [])
        .map((row) => {
          const label = String(row.label || '');
          const value = String(row.value || '');
          let rowClass = '';
          if (label.toLowerCase() === 'result') {
            rowClass = value.toLowerCase().includes('fail') ? 'result-row result-failed' : 'result-row result-success';
          }
          return `<tr class="${rowClass}"><th>${escapeHtml(label)}</th><td>${escapeHtml(value)}</td></tr>`;
        })
        .join('');

      if (!rows) {
        return '';
      }

      return `<h2>${escapeHtml(section.heading)}</h2><table role="presentation" class="summary-table"><tbody>${rows}</tbody></table>`;
    })
    .join('');

  return [
    '<!doctype html>',
    '<html>',
    '<head>',
    '<meta charset="utf-8" />',
    '<style>',
    'body { font-family: Segoe UI, Arial, sans-serif; color: #1f2937; margin: 0; padding: 0; background: #f8fafc; }',
    '.container { max-width: 860px; margin: 0 auto; background: #ffffff; padding: 24px; }',
    'h1 { margin: 0 0 18px; font-size: 20px; color: #111827; }',
    'h2 { margin: 18px 0 8px; font-size: 16px; color: #111827; }',
    '.summary-table { width: 100%; border-collapse: collapse; margin: 0 0 12px; }',
    '.summary-table th, .summary-table td { font-size: 13px; line-height: 1.4; padding: 8px 10px; border: 1px solid #e5e7eb; text-align: left; vertical-align: top; }',
    '.summary-table th { width: 34%; background: #f3f4f6; color: #111827; font-weight: 600; }',
    '.summary-table td { background: #ffffff; color: #1f2937; }',
    '.summary-table tbody tr:nth-child(even) td { background: #f9fafb; }',
    '.summary-table tbody tr.result-row th, .summary-table tbody tr.result-row td { font-weight: 700; }',
    '.summary-table tbody tr.result-success th, .summary-table tbody tr.result-success td { background: #ecfdf5; color: #065f46; }',
    '.summary-table tbody tr.result-failed th, .summary-table tbody tr.result-failed td { background: #fef2f2; color: #991b1b; }',
    '.failed-api-table { width: 100%; border-collapse: collapse; margin: 0 0 12px; }',
    '.failed-api-table th { background: #fef2f2; color: #7f1d1d; padding: 8px 10px; border: 1px solid #fca5a5; font-size: 13px; text-align: left; font-weight: 600; }',
    '.failed-api-table td { padding: 8px 10px; border: 1px solid #fca5a5; font-size: 13px; color: #1f2937; }',
    '.failed-api-table tr:nth-child(even) td { background: #fff5f5; }',
    '.no-failures { color: #065f46; font-size: 13px; margin: 0 0 12px; }',
    '.footer { margin-top: 16px; font-size: 12px; color: #6b7280; }',
    '</style>',
    '</head>',
    '<body>',
    '<div class="container">',
    `<h1>${escapeHtml(title)}</h1>`,
    renderedSections,
    '<div class="footer">This is an automated message from NW Interstellar API Automation.</div>',
    '</div>',
    '</body>',
    '</html>'
  ].join('');
}

function toExistingMailAttachments(filePaths) {
  return (Array.isArray(filePaths) ? filePaths : [])
    .filter((filePath) => filePath && typeof filePath === 'string' && fs.existsSync(filePath))
    .map((filePath) => ({
      filename: path.basename(filePath),
      path: filePath
    }));
}

function getAttachmentNames(attachments) {
  return (Array.isArray(attachments) ? attachments : [])
    .map((attachment) => attachment && attachment.filename)
    .filter((name) => !!name);
}

function sendSmtpNotification(config, mailPayload, done) {
  const finish = typeof done === 'function' ? done : () => {};
  if (!config || !config.enabled) {
    finish();
    return;
  }

  if (!nodemailer) {
    console.warn('SMTP notifications enabled but nodemailer is not installed. Run npm install and try again.');
    finish();
    return;
  }

  if (!isSmtpConfigValid(config)) {
    console.warn('SMTP notifications enabled but configuration is incomplete. Required: host, from, to.');
    finish();
    return;
  }

  const transportConfig = {
    host: config.host,
    port: config.port,
    secure: config.secure,
    tls: {
      rejectUnauthorized: false
    }
  };

  const authUser = config.user || config.from;
  if (config.pass && authUser) {
    transportConfig.auth = {
      user: authUser,
      pass: config.pass
    };
  }

  const transporter = nodemailer.createTransport(transportConfig);
  const email = {
    from: config.from,
    to: config.to.join(', '),
    subject: mailPayload.subject,
    text: mailPayload.text
  };

  if (mailPayload.html) {
    email.html = mailPayload.html;
  }

  if (Array.isArray(config.cc) && config.cc.length > 0) {
    email.cc = config.cc.join(', ');
  }

  if (Array.isArray(mailPayload.attachments) && mailPayload.attachments.length > 0) {
    email.attachments = mailPayload.attachments;
  }

  transporter.sendMail(email, (error, info) => {
    if (error) {
      console.warn(`SMTP notification failed: ${error.message}`);
    } else {
      console.log(`SMTP notification sent: ${info && info.messageId ? info.messageId : 'OK'}`);
    }
    finish();
  });
}

function finalizeRun(exitCode, smtpConfig, mailPayload) {
  if (!smtpConfig || !smtpConfig.enabled || !mailPayload) {
    process.exit(exitCode);
    return;
  }

  sendSmtpNotification(smtpConfig, mailPayload, () => {
    process.exit(exitCode);
  });
}

function buildSingleRunMailPayload(smtpConfig, options) {
  const {
    statusLabel,
    collectionPath,
    environmentPath,
    iterationDataPath,
    failures,
    totals,
    htmlReportPath,
    xlsxReportPath,
    passCount,
    failCount,
    nullDataResponses,
    emptyDataResponses,
    notes,
    failedRows
  } = options;

  const assertions = totals && totals.assertions ? totals.assertions : {};
  const requests = totals && totals.requests ? totals.requests : {};
  const assertionsTotal = assertions.total || 0;
  const assertionsFailed = assertions.failed || 0;
  const assertionsPassed = Math.max(0, assertionsTotal - assertionsFailed);
  const generatedAt = new Date().toISOString();
  const collectionName = path.basename(collectionPath || 'collection-run');
  const subject = buildSmtpSubject(smtpConfig, statusLabel, path.basename(collectionPath || 'collection-run'));
  const attachments = toExistingMailAttachments([htmlReportPath, xlsxReportPath]);
  const attachmentNames = getAttachmentNames(attachments);
  const attachedReportsLabel = attachmentNames.length > 0 ? attachmentNames.join(', ') : 'No report attachments available';

  const text = buildSmtpText([
    'NW Interstellar API Automation - Execution Summary',
    '',
    `Result: ${statusLabel}`,
    'Run Type: Single Collection',
    `Generated At (UTC): ${generatedAt}`,
    '',
    'Run Details',
    `- Collection: ${collectionName}`,
    `- Environment: QA Execution`,
    `- Input Data: Attached in report artifacts`,
    '',
    'Quality Summary',
    `- Requests Total: ${requests.total || 0}`,
    `- Assertions Total: ${assertionsTotal}`,
    `- Assertions Passed: ${assertionsPassed}`,
    `- Assertions Failed: ${assertionsFailed}`,
    `- Result Pass Count: ${passCount || 0}`,
    `- Result Fail Count: ${failCount || 0}`,
    `- Run Failures: ${failures || 0}`,
    `- Null Data Responses: ${nullDataResponses || 0}`,
    `- Empty Data Responses: ${emptyDataResponses || 0}`,
    notes ? `- Notes: ${notes}` : undefined,
    '',
    'Failed APIs',
    ...((() => {
      const byApi = new Map();
      (Array.isArray(failedRows) ? failedRows : []).forEach((row) => {
        const api = row.collection || row.requestName || 'Unknown API';
        if (!byApi.has(api)) byApi.set(api, new Set());
        byApi.get(api).add(row.ticker || 'Unknown');
      });
      return byApi.size > 0
        ? Array.from(byApi.entries()).map(([api, tickers]) => `  ${api}: ${Array.from(tickers).join(', ')}`)
        : ['  None'];
    })()),
    '',
    `Attached Reports: ${attachedReportsLabel}`
  ]);

  const html = buildSmtpHtml('NW Interstellar API Automation - Execution Summary', [
    {
      heading: 'Run Summary',
      rows: [
        { label: 'Result', value: statusLabel },
        { label: 'Run Type', value: 'Single Collection' },
        { label: 'Generated At (UTC)', value: generatedAt }
      ]
    },
    {
      heading: 'Run Details',
      rows: [
        { label: 'Collection', value: collectionName },
        { label: 'Environment', value: 'QA Execution' },
        { label: 'Input Data', value: 'Included in generated report artifacts' }
      ]
    },
    {
      heading: 'Quality Summary',
      rows: [
        { label: 'Requests Total', value: String(requests.total || 0) },
        { label: 'Assertions Total', value: String(assertionsTotal) },
        { label: 'Assertions Passed', value: String(assertionsPassed) },
        { label: 'Assertions Failed', value: String(assertionsFailed) },
        { label: 'Result Pass Count', value: String(passCount || 0) },
        { label: 'Result Fail Count', value: String(failCount || 0) },
        { label: 'Run Failures', value: String(failures || 0) },
        { label: 'Null Data Responses', value: String(nullDataResponses || 0) },
        { label: 'Empty Data Responses', value: String(emptyDataResponses || 0) },
        { label: 'Notes', value: notes || 'N/A' }
      ]
    },
    {
      heading: 'Reports',
      rows: [
        { label: 'Attached Reports', value: attachedReportsLabel }
      ]
    }
  ]);

  const failedApiHtml = buildFailedApiTableHtml(Array.isArray(failedRows) ? failedRows : []);
  const finalHtml = html.replace('<div class="footer">', `${failedApiHtml}<div class="footer">`);

  return {
    subject,
    text,
    html: finalHtml,
    attachments
  };
}

function buildFailedApiTableHtml(failedRows) {
  const byApi = new Map();
  (Array.isArray(failedRows) ? failedRows : []).forEach((row) => {
    const api = row.collection || row.requestName || 'Unknown API';
    if (!byApi.has(api)) {
      byApi.set(api, new Set());
    }
    byApi.get(api).add(row.ticker || 'Unknown');
  });

  if (byApi.size === 0) {
    return '<p class="no-failures">No API failures detected.</p>';
  }

  const headers = ['API / Collection', 'Failing Tickers'];
  const headerCells = headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('');
  const bodyRows = Array.from(byApi.entries()).map(([api, tickers]) => [
    '<tr>',
    `<td>${escapeHtml(api)}</td>`,
    `<td>${escapeHtml(Array.from(tickers).join(', '))}</td>`,
    '</tr>'
  ].join('')).join('');

  return `<h2>Failed APIs (${byApi.size} API(s) with failures)</h2><table class="failed-api-table"><thead><tr>${headerCells}</tr></thead><tbody>${bodyRows}</tbody></table>`;
}

function buildAllCollectionsMailPayload(smtpConfig, options) {
  const {
    statusLabel,
    totalCollections,
    failedCollections,
    totalRequests,
    totalAssertions,
    failedAssertions,
    passCount,
    failCount,
    nullDataResponses,
    emptyDataResponses,
    failedCollectionNames,
    consolidatedHtmlPath,
    consolidatedXlsxPath,
    failedRows
  } = options;

  const passedCollections = Math.max(0, (totalCollections || 0) - (failedCollections || 0));
  const assertionsPassed = Math.max(0, (totalAssertions || 0) - (failedAssertions || 0));
  const generatedAt = new Date().toISOString();
  const failedList = Array.isArray(failedCollectionNames) && failedCollectionNames.length > 0
    ? failedCollectionNames.join(', ')
    : 'None';
  const attachments = toExistingMailAttachments([consolidatedHtmlPath, consolidatedXlsxPath]);
  const attachmentNames = getAttachmentNames(attachments);
  const attachedReportsLabel = attachmentNames.length > 0 ? attachmentNames.join(', ') : 'No consolidated report attachments available';

  const subject = buildSmtpSubject(smtpConfig, statusLabel, 'All Collections');
  const text = buildSmtpText([
    'NW Interstellar API Automation - Consolidated Execution Summary',
    '',
    `Result: ${statusLabel}`,
    'Run Type: All Collections',
    `Generated At (UTC): ${generatedAt}`,
    '',
    'Collection Summary',
    `- Total Collections: ${totalCollections || 0}`,
    `- Passed Collections: ${passedCollections}`,
    `- Failed Collections: ${failedCollections || 0}`,
    `- Failed Collection Names: ${failedList}`,
    '',
    'Quality Summary',
    `- Total Requests: ${totalRequests || 0}`,
    `- Total Assertions: ${totalAssertions || 0}`,
    `- Assertions Passed: ${assertionsPassed}`,
    `- Assertions Failed: ${failedAssertions || 0}`,
    `- Result Pass Count: ${passCount || 0}`,
    `- Result Fail Count: ${failCount || 0}`,
    `- Null Data Responses: ${nullDataResponses || 0}`,
    `- Empty Data Responses: ${emptyDataResponses || 0}`,
    '',
    'Failed APIs',
    ...((() => {
      const byApi = new Map();
      (Array.isArray(failedRows) ? failedRows : []).forEach((row) => {
        const api = row.collection || row.requestName || 'Unknown API';
        if (!byApi.has(api)) byApi.set(api, new Set());
        byApi.get(api).add(row.ticker || 'Unknown');
      });
      return byApi.size > 0
        ? Array.from(byApi.entries()).map(([api, tickers]) => `  ${api}: ${Array.from(tickers).join(', ')}`)
        : ['  None'];
    })()),
    '',
    `Attached Reports: ${attachedReportsLabel}`
  ]);

  const html = buildSmtpHtml('NW Interstellar API Automation - Consolidated Execution Summary', [
    {
      heading: 'Run Summary',
      rows: [
        { label: 'Result', value: statusLabel },
        { label: 'Run Type', value: 'All Collections' },
        { label: 'Generated At (UTC)', value: generatedAt }
      ]
    },
    {
      heading: 'Collection Summary',
      rows: [
        { label: 'Total Collections', value: String(totalCollections || 0) },
        { label: 'Passed Collections', value: String(passedCollections) },
        { label: 'Failed Collections', value: String(failedCollections || 0) },
        { label: 'Failed Collection Names', value: failedList }
      ]
    },
    {
      heading: 'Quality Summary',
      rows: [
        { label: 'Total Requests', value: String(totalRequests || 0) },
        { label: 'Total Assertions', value: String(totalAssertions || 0) },
        { label: 'Assertions Passed', value: String(assertionsPassed) },
        { label: 'Assertions Failed', value: String(failedAssertions || 0) },
        { label: 'Result Pass Count', value: String(passCount || 0) },
        { label: 'Result Fail Count', value: String(failCount || 0) },
        { label: 'Null Data Responses', value: String(nullDataResponses || 0) },
        { label: 'Empty Data Responses', value: String(emptyDataResponses || 0) }
      ]
    },
    {
      heading: 'Reports',
      rows: [
        { label: 'Attached Reports', value: attachedReportsLabel }
      ]
    }
  ]);

  const failedApiHtml = buildFailedApiTableHtml(Array.isArray(failedRows) ? failedRows : []);
  const finalHtml = html.replace('<div class="footer">', `${failedApiHtml}<div class="footer">`);

  return {
    subject,
    text,
    html: finalHtml,
    attachments
  };
}

function getEnvironmentVariableValue(environmentObject, key) {
  if (!environmentObject || !Array.isArray(environmentObject.values)) {
    return undefined;
  }

  const found = environmentObject.values.find((entry) => entry && entry.key === key);
  return found ? found.value : undefined;
}

function readJsonFile(filePath) {
  const rawText = fs.readFileSync(filePath, 'utf8');
  const text = rawText.charCodeAt(0) === 0xFEFF ? rawText.slice(1) : rawText;
  return JSON.parse(text);
}

function findFirstValueByKeysCaseInsensitive(source, candidateKeys) {
  if (!source || typeof source !== 'object') {
    return undefined;
  }

  const toCanonical = (value) => String(value).toLowerCase().replace(/[^a-z0-9]/g, '');
  const entries = Object.entries(source);
  const canonicalEntries = entries.map(([key, value]) => [toCanonical(key), value]);

  for (const candidateKey of candidateKeys) {
    const found = canonicalEntries.find(([key]) => key === toCanonical(candidateKey));
    if (found && typeof found[1] !== 'undefined' && found[1] !== null && String(found[1]).trim() !== '') {
      return String(found[1]).trim();
    }
  }

  return undefined;
}

function normalizeIterationRows(rows) {
  if (!Array.isArray(rows)) {
    return [];
  }

  const keyCandidates = ['fundCode', 'fund_code', 'fundcode', 'ticker', 'symbol', 'code'];

  return rows
    .map((row) => {
      if (!row || typeof row !== 'object') {
        return null;
      }

      const normalizedRow = { ...row };
      const fundCodeValue = findFirstValueByKeysCaseInsensitive(row, keyCandidates);
      if (fundCodeValue) {
        normalizedRow.fundCode = fundCodeValue;
      }

      return normalizedRow;
    })
    .filter((row) => row && row.fundCode);
}

function loadIterationData(filePath) {
  if (!filePath) {
    return undefined;
  }

  const extension = path.extname(filePath).toLowerCase();
  if (extension === '.json') {
    return normalizeIterationRows(readJsonFile(filePath));
  }

  if (extension === '.csv') {
    if (!xlsx) {
      console.error('CSV iteration data requires the xlsx package. Run npm install and try again.');
      process.exit(1);
    }

    const workbook = xlsx.readFile(filePath, { raw: false });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(sheet, { defval: '' });
    const normalizedRows = normalizeIterationRows(rows);

    if (normalizedRows.length === 0) {
      console.error(`No usable ticker rows found in CSV: ${filePath}`);
      console.error('Expected a column like fundCode or ticker with non-empty values.');
      process.exit(1);
    }

    return normalizedRows;
  }

  console.error(`Unsupported iteration data format: ${extension || 'unknown'} (file: ${filePath})`);
  console.error('Use a .json or .csv data file.');
  process.exit(1);
}

function maskValueInFile(filePath, sensitiveValue, replacement) {
  if (!filePath || !sensitiveValue || !fs.existsSync(filePath)) {
    return;
  }

  const text = fs.readFileSync(filePath, 'utf8');
  if (!text.includes(sensitiveValue)) {
    return;
  }

  const maskedText = text.split(sensitiveValue).join(replacement);
  fs.writeFileSync(filePath, maskedText);
}

function toCsvCell(value) {
  if (value === null || typeof value === 'undefined') {
    return '';
  }

  const stringValue = String(value);
  const escapedValue = stringValue.replace(/"/g, '""');
  return `"${escapedValue}"`;
}

function getResponseBodyText(execution) {
  if (!execution || !execution.response) {
    return null;
  }

  const stream = execution.response.stream;
  if (Buffer.isBuffer(stream)) {
    return stream.toString('utf8');
  }

  if (Array.isArray(stream)) {
    return Buffer.from(stream).toString('utf8');
  }

  if (typeof stream === 'string') {
    return stream;
  }

  if (stream && typeof stream.toString === 'function') {
    return stream.toString('utf8');
  }

  return null;
}

function detectResponseDataState(execution) {
  const responseBody = getResponseBodyText(execution);
  if (responseBody === null || typeof responseBody === 'undefined') {
    return '';
  }

  const trimmedBody = String(responseBody).trim();
  if (!trimmedBody) {
    return 'Empty';
  }

  try {
    const parsedBody = JSON.parse(trimmedBody);
    if (parsedBody === null) {
      return 'Null';
    }

    if (
      parsedBody
      && typeof parsedBody === 'object'
      && Object.prototype.hasOwnProperty.call(parsedBody, 'data')
      && parsedBody.data === null
    ) {
      return 'Null';
    }
  } catch (_error) {
    return '';
  }

  return '';
}

function buildExecutionResultsCsv(rows) {
  const header = ['requestName', 'ticker', 'responseCode', 'responseStatus', 'responseTimeMs', 'responseDataState', 'result'];
  const lines = [header.map(toCsvCell).join(',')];

  rows.forEach((row) => {
    lines.push([
      row.requestName,
      row.ticker,
      row.responseCode,
      row.responseStatus,
      row.responseTimeMs,
      row.responseDataState,
      row.result
    ].map(toCsvCell).join(','));
  });

  return `${lines.join('\n')}\n`;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function buildConsolidatedCsv(rows) {
  const header = ['collection', 'requestName', 'ticker', 'responseCode', 'responseStatus', 'responseTimeMs', 'responseDataState', 'result'];
  const lines = [header.map(toCsvCell).join(',')];

  rows.forEach((row) => {
    lines.push([
      row.collection,
      row.requestName,
      row.ticker,
      row.responseCode,
      row.responseStatus,
      row.responseTimeMs,
      row.responseDataState,
      row.result
    ].map(toCsvCell).join(','));
  });

  return `${lines.join('\n')}\n`;
}

function calculateDataStateCounts(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  let nullCount = 0;
  let emptyCount = 0;

  safeRows.forEach((row) => {
    const state = String((row && row.responseDataState) || '').trim().toLowerCase();
    if (state === 'null') {
      nullCount += 1;
    } else if (state === 'empty') {
      emptyCount += 1;
    }
  });

  return {
    nullCount,
    emptyCount,
    total: nullCount + emptyCount
  };
}

function getExecutionResultStatus(responseCode, responseDataState) {
  const statusCode = Number(responseCode);
  const dataState = String(responseDataState || '').trim().toLowerCase();
  return statusCode === 200 ? 'Pass' : 'Fail';
}

function calculateResultCounts(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  let passCount = 0;
  let failCount = 0;

  safeRows.forEach((row) => {
    const value = String((row && row.result) || '').trim().toLowerCase();
    if (value === 'pass') {
      passCount += 1;
    } else if (value === 'fail') {
      failCount += 1;
    }
  });

  return {
    passCount,
    failCount,
    total: passCount + failCount
  };
}

function buildConsolidatedHtml(reportData) {
  const generatedAt = escapeHtml(reportData.generatedAt);
  const totalCollections = escapeHtml(reportData.totalCollections);
  const failedCollections = escapeHtml(reportData.failedCollections);
  const totalRequests = escapeHtml(reportData.totalRequests);
  const totalAssertions = escapeHtml(reportData.totalAssertions);
  const failedAssertions = escapeHtml(reportData.failedAssertions);
  const nullDataResponses = escapeHtml(reportData.nullDataResponses || 0);
  const emptyDataResponses = escapeHtml(reportData.emptyDataResponses || 0);

  const rows = reportData.executionRows.map((row) => {
    const state = String(row.responseDataState || '').toLowerCase();
    const rowClass = state === 'null' || state === 'empty' ? 'data-alert' : '';
    return `<tr class="${rowClass}"><td>${escapeHtml(row.collection)}</td><td>${escapeHtml(row.requestName || '')}</td><td>${escapeHtml(row.ticker || '')}</td><td>${escapeHtml(row.responseCode || '')}</td><td>${escapeHtml(row.responseStatus || '')}</td><td>${escapeHtml(row.responseTimeMs || '')}</td><td>${escapeHtml(row.responseDataState || '')}</td><td>${escapeHtml(row.result || '')}</td></tr>`;
  }).join('');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Consolidated API Report</title>
  <style>
    body { font-family: Segoe UI, Arial, sans-serif; margin: 20px; }
    h1 { margin-bottom: 8px; }
    .meta { margin-bottom: 16px; color: #333; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background: #f3f6fb; }
    tr:nth-child(even) { background: #fafafa; }
    tr.data-alert { background: #fff4db !important; }
  </style>
</head>
<body>
  <h1>Consolidated API Report</h1>
  <div class="meta">Generated: ${generatedAt}</div>
  <div class="meta">Collections: ${totalCollections} | Failed Collections: ${failedCollections} | Requests: ${totalRequests} | Assertions: ${totalAssertions} | Failed Assertions: ${failedAssertions}</div>
  <div class="meta"><strong>Business Data Alerts</strong> | Null Data Responses: ${nullDataResponses} | Empty Data Responses: ${emptyDataResponses}</div>
  <table>
    <thead>
      <tr>
        <th>Collection</th>
        <th>Request Name</th>
        <th>Ticker</th>
        <th>Response Code</th>
        <th>Status</th>
        <th>Response Time (ms)</th>
        <th>Response Data State</th>
        <th>Result</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
</body>
</html>`;
}

function toWorksheetName(rawName) {
  const fallback = 'Sheet';
  const value = String(rawName || '').trim();
  const cleaned = value
    .replace(/\.postman_collection\.json$/i, '')
    .replace(/[\\/?*\[\]:]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const safeName = cleaned || fallback;
  return safeName.slice(0, 31);
}

function toUniqueWorksheetName(baseName, usedNames) {
  let candidate = toWorksheetName(baseName);
  if (!usedNames.has(candidate)) {
    usedNames.add(candidate);
    return candidate;
  }

  let counter = 2;
  while (counter < 1000) {
    const suffix = ` (${counter})`;
    const maxBaseLength = 31 - suffix.length;
    const trimmedBase = candidate.slice(0, maxBaseLength);
    const nextCandidate = `${trimmedBase}${suffix}`;
    if (!usedNames.has(nextCandidate)) {
      usedNames.add(nextCandidate);
      return nextCandidate;
    }
    counter += 1;
  }

  const timestampName = `Sheet-${Date.now()}`.slice(0, 31);
  usedNames.add(timestampName);
  return timestampName;
}

function removeFileIfExists(filePath) {
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
}

function ensureHeader(requestObject, headerKey, headerValue) {
  if (!requestObject) {
    return;
  }

  requestObject.header = Array.isArray(requestObject.header) ? requestObject.header : [];
  const hasHeader = requestObject.header.some((header) =>
    header
    && typeof header.key === 'string'
    && header.key.toLowerCase() === headerKey.toLowerCase()
  );

  if (!hasHeader) {
    requestObject.header.push({
      key: headerKey,
      value: headerValue,
      type: 'text'
    });
  }
}

function applyCommonHeadersToItems(items) {
  if (!Array.isArray(items)) {
    return;
  }

  items.forEach((item) => {
    if (item && item.request) {
      ensureHeader(item.request, 'client_id', '{{clientId}}');
      ensureHeader(item.request, 'X-NW-Message-ID', '{{headerMsgId}}');
    }

    if (item && Array.isArray(item.item)) {
      applyCommonHeadersToItems(item.item);
    }
  });
}

function loadCollectionWithCommonHeaders(filePath) {
  const collectionObject = require(filePath);
  applyCommonHeadersToItems(collectionObject.item);
  return collectionObject;
}

function resolvePath(inputPath, fallbackFolder) {
  if (!inputPath) {
    return undefined;
  }

  if (path.isAbsolute(inputPath)) {
    return inputPath;
  }

  const fallbackCandidate = path.resolve(projectRoot, fallbackFolder, inputPath);
  if (fs.existsSync(fallbackCandidate)) {
    return fallbackCandidate;
  }

  const projectRootCandidate = path.resolve(projectRoot, inputPath);
  if (fs.existsSync(projectRootCandidate)) {
    return projectRootCandidate;
  }

  return fallbackCandidate;
}

function getDefaultCollectionPath() {
  const collectionsDir = path.resolve(projectRoot, 'collections');
  if (!fs.existsSync(collectionsDir)) {
    return undefined;
  }

  const files = fs.readdirSync(collectionsDir)
    .filter((fileName) => fileName.endsWith('.postman_collection.json'))
    .sort();

  if (files.length === 0) {
    return undefined;
  }

  return path.resolve(collectionsDir, files[0]);
}

function getAllCollectionPaths() {
  const collectionsDir = path.resolve(projectRoot, 'collections');
  if (!fs.existsSync(collectionsDir)) {
    return [];
  }

  return fs.readdirSync(collectionsDir)
    .filter((fileName) => fileName.endsWith('.postman_collection.json'))
    .sort()
    .map((fileName) => path.resolve(collectionsDir, fileName));
}

function getCollectionBaseName(collectionFilePath) {
  return path.basename(collectionFilePath, '.postman_collection.json');
}

function toTitleCaseToken(token) {
  const value = String(token || '').trim();
  if (!value) {
    return '';
  }

  if (/^\d+[a-z]*$/i.test(value)) {
    return value.toUpperCase();
  }

  return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
}

function getCollectionDisplayName(collectionFilePath) {
  const baseName = getCollectionBaseName(collectionFilePath);
  const normalized = baseName.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
  const prettyName = normalized
    .split(' ')
    .map((token) => toTitleCaseToken(token))
    .join(' ')
    .trim();

  if (!prettyName) {
    return 'Collection';
  }

  if (/\b(current|historical|prod|qa|uat)\b/i.test(prettyName)) {
    return prettyName;
  }

  return `${prettyName} Current`;
}

function findMatchingEnvironmentPath(collectionFilePath) {
  const environmentsDir = path.resolve(projectRoot, 'environments');
  if (!fs.existsSync(environmentsDir)) {
    return undefined;
  }

  const baseName = getCollectionBaseName(collectionFilePath);
  const matches = fs.readdirSync(environmentsDir)
    .filter((fileName) => fileName.startsWith(`${baseName}.`) && fileName.endsWith('.postman_environment.json'))
    .sort();

  if (matches.length === 0) {
    return undefined;
  }

  return path.resolve(environmentsDir, matches[0]);
}

function findMatchingDataPath(collectionFilePath) {
  const dataDir = path.resolve(projectRoot, 'data');
  if (!fs.existsSync(dataDir)) {
    return undefined;
  }

  const baseName = getCollectionBaseName(collectionFilePath);
  const exactFile = path.resolve(dataDir, `${baseName}.tickers.json`);
  if (fs.existsSync(exactFile)) {
    return exactFile;
  }

  return undefined;
}

function collectionUsesTickerVariables(collectionFilePath) {
  if (!collectionFilePath || !fs.existsSync(collectionFilePath)) {
    return true;
  }

  try {
    const text = fs.readFileSync(collectionFilePath, 'utf8');
    return /\{\{\s*(fundCode|styleFundCode)\s*\}\}/i.test(text);
  } catch (_error) {
    return true;
  }
}

function getDefaultEnvironmentPath() {
  const environmentsDir = path.resolve(projectRoot, 'environments');
  if (!fs.existsSync(environmentsDir)) {
    return undefined;
  }

  const files = fs.readdirSync(environmentsDir)
    .filter((fileName) => fileName.endsWith('.postman_environment.json'))
    .sort();

  if (files.length === 0) {
    return undefined;
  }

  return path.resolve(environmentsDir, files[0]);
}

function getDefaultDataPath() {
  const dataDir = path.resolve(projectRoot, 'data');
  if (!fs.existsSync(dataDir)) {
    return undefined;
  }

  const files = fs.readdirSync(dataDir)
    .filter((fileName) => fileName.endsWith('.json'))
    .sort();

  if (files.length === 0) {
    return undefined;
  }

  return path.resolve(dataDir, files[0]);
}

function ensureFileExists(filePath, label) {
  if (!filePath) {
    return;
  }

  if (!fs.existsSync(filePath)) {
    console.error(`${label} file not found: ${filePath}`);
    process.exit(1);
  }
}

const collectionArg = getArgValue('--collection');
const environmentArg = getArgValue('--env');
const dataArg = getArgValue('--data');
const noDataArg = getBooleanArg('--no-data', false);
const runAllCollections = getBooleanArg('--all', false) || String(collectionArg || '').toLowerCase() === 'all';
const insecure = getBooleanArg('--insecure', true);
const maskClientId = getBooleanArg('--mask-client-id', true);
const archiveReports = getBooleanArg('--archive-reports', false);
const hideReportSecrets = getBooleanArg('--hide-report-secrets', true);
const smtpConfig = resolveSmtpConfig();

const collectionPath = collectionArg ? resolvePath(collectionArg, 'collections') : getDefaultCollectionPath();
const collectionRequiresIterationData = !runAllCollections && collectionPath
  ? collectionUsesTickerVariables(collectionPath)
  : true;
const environmentPath = environmentArg ? resolvePath(environmentArg, 'environments') : getDefaultEnvironmentPath();
const iterationDataPath = noDataArg
  ? undefined
  : (dataArg
    ? resolvePath(dataArg, 'data')
    : (collectionRequiresIterationData ? getDefaultDataPath() : undefined));
const iterationData = loadIterationData(iterationDataPath);
const environmentObject = environmentPath ? readJsonFile(environmentPath) : undefined;
const reportsDir = path.resolve(projectRoot, 'reports');
const runStamp = new Date().toISOString().replace(/[.:]/g, '-');
const latestReportFile = path.resolve(reportsDir, 'newman-report-latest.html');
const latestJunitFile = path.resolve(reportsDir, 'newman-junit-latest.xml');
const latestJsonFile = path.resolve(reportsDir, 'newman-run-latest.json');
const latestSummaryFile = path.resolve(reportsDir, 'newman-summary-latest.json');
const latestCsvFile = path.resolve(reportsDir, 'newman-response-codes-latest.csv');
const reportFile = archiveReports ? path.resolve(reportsDir, `newman-report-${runStamp}.html`) : latestReportFile;
const junitFile = archiveReports ? path.resolve(reportsDir, `newman-junit-${runStamp}.xml`) : latestJunitFile;
const jsonFile = archiveReports ? path.resolve(reportsDir, `newman-run-${runStamp}.json`) : latestJsonFile;
const summaryFile = archiveReports ? path.resolve(reportsDir, `newman-summary-${runStamp}.json`) : latestSummaryFile;
const csvFile = archiveReports ? path.resolve(reportsDir, `newman-response-codes-${runStamp}.csv`) : latestCsvFile;

if (runAllCollections) {
  const collectionPaths = getAllCollectionPaths();
  if (collectionPaths.length === 0) {
    console.error('No collections found under collections/.');
    process.exit(1);
  }

  const forwardedArgs = [];
  for (let i = 2; i < process.argv.length; i += 1) {
    const arg = process.argv[i];
    const next = process.argv[i + 1];

    if (arg === '--collection') {
      i += 1;
      continue;
    }
    if (arg === '--all') {
      if (typeof next !== 'undefined' && !String(next).startsWith('--')) {
        i += 1;
      }
      continue;
    }
    if (arg === '--archive-reports') {
      if (typeof next !== 'undefined' && !String(next).startsWith('--')) {
        i += 1;
      }
      continue;
    }

    forwardedArgs.push(arg);
  }

  let failedRuns = 0;
  const perCollectionResults = [];
  const consolidatedStamp = new Date().toISOString().replace(/[.:]/g, '-');
  const consolidatedJsonPath = path.resolve(reportsDir, `API_Response_report_${consolidatedStamp}.json`);
  const consolidatedCsvPath = path.resolve(reportsDir, `API_Response_report_${consolidatedStamp}.csv`);
  const consolidatedHtmlPath = path.resolve(reportsDir, `API_Response_report_${consolidatedStamp}.html`);
  const consolidatedXlsxPath = path.resolve(reportsDir, `API_Response_report_${consolidatedStamp}.xlsx`);
  const latestSummaryPath = path.resolve(reportsDir, 'newman-summary-latest.json');
  const intermediateLatestArtifacts = [
    path.resolve(reportsDir, 'newman-report-latest.html'),
    path.resolve(reportsDir, 'newman-junit-latest.xml'),
    path.resolve(reportsDir, 'newman-run-latest.json'),
    path.resolve(reportsDir, 'newman-summary-latest.json'),
    path.resolve(reportsDir, 'newman-response-codes-latest.csv')
  ];

  intermediateLatestArtifacts.forEach((filePath) => removeFileIfExists(filePath));

  const hasExplicitEnv = forwardedArgs.includes('--env');
  const hasExplicitData = forwardedArgs.includes('--data');
  const smtpFlags = new Set([
    '--smtp-enabled',
    '--smtp-host',
    '--smtp-port',
    '--smtp-secure',
    '--smtp-user',
    '--smtp-pass',
    '--smtp-from',
    '--smtp-to',
    '--smtp-cc',
    '--smtp-subject-prefix'
  ]);
  console.log(`Running all collections: ${collectionPaths.length} found.`);
  collectionPaths.forEach((singleCollectionPath, index) => {
    const displayName = path.basename(singleCollectionPath);
    const displayCollectionName = getCollectionDisplayName(singleCollectionPath);
    console.log(`\n[${index + 1}/${collectionPaths.length}] Running ${displayName}`);

    const perCollectionArgs = [...forwardedArgs];

    for (let i = 0; i < perCollectionArgs.length; i += 1) {
      if (!smtpFlags.has(perCollectionArgs[i])) {
        continue;
      }

      perCollectionArgs.splice(i, 1);
      if (i < perCollectionArgs.length && !String(perCollectionArgs[i]).startsWith('--')) {
        perCollectionArgs.splice(i, 1);
      }
      i -= 1;
    }

    // Child runs must not send mail; only the final consolidated run should notify.
    perCollectionArgs.push('--smtp-enabled', 'false');

    const requiresIterationData = collectionUsesTickerVariables(singleCollectionPath);

    if (!requiresIterationData) {
      for (let i = 0; i < perCollectionArgs.length; i += 1) {
        if (perCollectionArgs[i] === '--data') {
          perCollectionArgs.splice(i, 2);
          i -= 1;
        }
      }
      perCollectionArgs.push('--no-data', 'true');
    }

    if (!hasExplicitEnv) {
      const matchingEnvPath = findMatchingEnvironmentPath(singleCollectionPath);
      if (matchingEnvPath) {
        perCollectionArgs.push('--env', matchingEnvPath);
      }
    }
    if (!hasExplicitData && requiresIterationData) {
      const matchingDataPath = findMatchingDataPath(singleCollectionPath);
      if (matchingDataPath) {
        perCollectionArgs.push('--data', matchingDataPath);
      }
    }

    const result = cp.spawnSync(
      process.execPath,
      [__filename, '--collection', singleCollectionPath, ...perCollectionArgs, '--archive-reports', 'false'],
      {
        cwd: projectRoot,
        stdio: 'inherit'
      }
    );

    if (result.status !== 0) {
      failedRuns += 1;
    }

    let summaryData = null;
    if (fs.existsSync(latestSummaryPath)) {
      try {
        summaryData = JSON.parse(fs.readFileSync(latestSummaryPath, 'utf8'));
      } catch (error) {
        summaryData = null;
      }
    }

    perCollectionResults.push({
      collection: displayName,
      collectionDisplayName: displayCollectionName,
      status: result.status,
      summary: summaryData
    });

    // Keep run output clean so only consolidated timestamped reports remain.
    intermediateLatestArtifacts.forEach((filePath) => removeFileIfExists(filePath));
  });

  const executionRows = [];
  const executionRowsByCollection = {};
  const dataStateCountsByCollection = {};
  const resultCountsByCollection = {};
  let totalRequests = 0;
  let totalAssertions = 0;
  let failedAssertions = 0;

  perCollectionResults.forEach((entry) => {
    const collectionKey = entry.collectionDisplayName || entry.collection;
    executionRowsByCollection[collectionKey] = [];
    dataStateCountsByCollection[collectionKey] = { nullCount: 0, emptyCount: 0, total: 0 };
    resultCountsByCollection[collectionKey] = { passCount: 0, failCount: 0, total: 0 };

    const stats = entry.summary && entry.summary.totals ? entry.summary.totals : null;
    totalRequests += stats && stats.requests ? (stats.requests.total || 0) : 0;
    totalAssertions += stats && stats.assertions ? (stats.assertions.total || 0) : 0;
    failedAssertions += stats && stats.assertions ? (stats.assertions.failed || 0) : 0;

    const rows = entry.summary && Array.isArray(entry.summary.executionResults)
      ? entry.summary.executionResults
      : [];

    rows.forEach((row) => {
      const normalizedRow = {
        collection: collectionKey,
        requestName: row.requestName,
        ticker: row.ticker,
        responseCode: row.responseCode,
        responseStatus: row.responseStatus,
        responseTimeMs: row.responseTimeMs,
        responseDataState: row.responseDataState,
        result: getExecutionResultStatus(row.responseCode, row.responseDataState)
      };

      executionRows.push(normalizedRow);
      executionRowsByCollection[collectionKey].push(normalizedRow);
    });

    dataStateCountsByCollection[collectionKey] = calculateDataStateCounts(executionRowsByCollection[collectionKey]);
    resultCountsByCollection[collectionKey] = calculateResultCounts(executionRowsByCollection[collectionKey]);
  });

  const overallDataStateCounts = calculateDataStateCounts(executionRows);
  const overallResultCounts = calculateResultCounts(executionRows);
  const overviewRows = perCollectionResults.map((entry) => {
    const stats = entry.summary && entry.summary.totals ? entry.summary.totals : null;
    const failures = entry.summary && typeof entry.summary.failures === 'number' ? entry.summary.failures : 0;
    const dataStateCounts = dataStateCountsByCollection[entry.collectionDisplayName || entry.collection] || { nullCount: 0, emptyCount: 0 };
    const resultCounts = resultCountsByCollection[entry.collectionDisplayName || entry.collection] || { passCount: 0, failCount: 0 };
    return {
      collection: entry.collectionDisplayName || entry.collection,
      status: entry.status === 0 ? 'PASS' : 'FAIL',
      requests: stats && stats.requests ? (stats.requests.total || 0) : 0,
      assertions: stats && stats.assertions ? (stats.assertions.total || 0) : 0,
      failedAssertions: stats && stats.assertions ? (stats.assertions.failed || 0) : 0,
      passCount: resultCounts.passCount,
      failCount: resultCounts.failCount,
      failures,
      nullDataResponses: dataStateCounts.nullCount,
      emptyDataResponses: dataStateCounts.emptyCount
    };
  });

  const consolidatedReport = {
    generatedAt: new Date().toISOString(),
    totalCollections: collectionPaths.length,
    failedCollections: failedRuns,
    totalRequests,
    totalAssertions,
    failedAssertions,
    passCount: overallResultCounts.passCount,
    failCount: overallResultCounts.failCount,
    nullDataResponses: overallDataStateCounts.nullCount,
    emptyDataResponses: overallDataStateCounts.emptyCount,
    overview: overviewRows,
    collections: perCollectionResults,
    executionRows
  };

  const consolidatedCsv = buildConsolidatedCsv(executionRows);
  const consolidatedHtml = buildConsolidatedHtml(consolidatedReport);

  fs.writeFileSync(consolidatedJsonPath, JSON.stringify(consolidatedReport, null, 2));
  fs.writeFileSync(consolidatedCsvPath, consolidatedCsv);
  fs.writeFileSync(consolidatedHtmlPath, consolidatedHtml);

  if (xlsx) {
    const workbook = xlsx.utils.book_new();
    const usedSheetNames = new Set();
    const excludedExcelCollections = new Set(['Data Fee Current']);
    const excelOverviewRows = overviewRows.filter((row) => !excludedExcelCollections.has(row.collection));
    const excelExecutionRows = executionRows.filter((row) => !excludedExcelCollections.has(row.collection));

    const overviewSheetName = toUniqueWorksheetName('Overview', usedSheetNames);
    xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet(excelOverviewRows), overviewSheetName);

    const failedApiByTicker = new Map();
    excelExecutionRows
      .filter((row) => String(row.result || '').toLowerCase() === 'fail')
      .forEach((row) => {
        const api = row.collection || row.requestName || 'Unknown API';
        if (!failedApiByTicker.has(api)) failedApiByTicker.set(api, new Set());
        failedApiByTicker.get(api).add(row.ticker || 'Unknown');
      });

    xlsx.utils.book_append_sheet(
      workbook,
      xlsx.utils.json_to_sheet(
        failedApiByTicker.size > 0
          ? Array.from(failedApiByTicker.entries()).map(([api, tickers]) => ({
              collection: api,
              failingTickers: Array.from(tickers).join(', ')
            }))
          : [{ message: 'No API failures detected.' }]
      ),
      toUniqueWorksheetName('Failed API', usedSheetNames)
    );

    const consolidatedSheetName = toUniqueWorksheetName('Consolidated', usedSheetNames);
    xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet(excelExecutionRows), consolidatedSheetName);

    perCollectionResults.forEach((entry) => {
      const collectionKey = entry.collectionDisplayName || entry.collection;
      if (excludedExcelCollections.has(collectionKey)) {
        return;
      }
      const rows = executionRowsByCollection[collectionKey] || [];
      const sheetRows = rows.length > 0
        ? rows.map((row) => ({
          requestName: row.requestName,
          ticker: row.ticker,
          responseCode: row.responseCode,
          responseStatus: row.responseStatus,
          responseTimeMs: row.responseTimeMs,
          responseDataState: row.responseDataState,
          result: row.result
        }))
        : [{ message: 'No execution rows captured for this collection.' }];

      const sheetName = toUniqueWorksheetName(collectionKey, usedSheetNames);
      xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet(sheetRows), sheetName);
    });

    xlsx.writeFile(workbook, consolidatedXlsxPath);
  }

  removeFileIfExists(path.resolve(reportsDir, 'API_Response_report_latest.json'));
  removeFileIfExists(path.resolve(reportsDir, 'API_Response_report_latest.csv'));
  removeFileIfExists(path.resolve(reportsDir, 'API_Response_report_latest.html'));
  removeFileIfExists(path.resolve(reportsDir, 'API_Response_report_latest.xlsx'));

  removeFileIfExists(path.resolve(reportsDir, 'newman-report-latest.html'));
  removeFileIfExists(path.resolve(reportsDir, 'newman-junit-latest.xml'));
  removeFileIfExists(path.resolve(reportsDir, 'newman-run-latest.json'));
  removeFileIfExists(path.resolve(reportsDir, 'newman-summary-latest.json'));
  removeFileIfExists(path.resolve(reportsDir, 'newman-response-codes-latest.csv'));

  console.log('\nConsolidated report generated:');
  console.log(`JSON: ${consolidatedJsonPath}`);
  console.log(`CSV: ${consolidatedCsvPath}`);
  console.log(`HTML: ${consolidatedHtmlPath}`);
  if (xlsx) {
    console.log(`XLSX: ${consolidatedXlsxPath}`);
  } else {
    console.log('XLSX: skipped (xlsx package not installed)');
  }

  if (failedRuns > 0) {
    console.error(`\nCompleted with ${failedRuns} failing collection run(s).`);
    finalizeRun(
      1,
      smtpConfig,
      buildAllCollectionsMailPayload(smtpConfig, {
        statusLabel: 'FAIL',
        totalCollections: collectionPaths.length,
        failedCollections: failedRuns,
        totalRequests,
        totalAssertions,
        failedAssertions,
        passCount: overallResultCounts.passCount,
        failCount: overallResultCounts.failCount,
        nullDataResponses: overallDataStateCounts.nullCount,
        emptyDataResponses: overallDataStateCounts.emptyCount,
        failedCollectionNames: perCollectionResults
          .filter((entry) => {
            if (!entry || entry.status !== 0) return entry && entry.status !== 0;
            const execResults = entry.summary && Array.isArray(entry.summary.executionResults)
              ? entry.summary.executionResults : [];
            return execResults.some((r) => String(r.result || '').toLowerCase() === 'fail');
          })
          .map((entry) => entry.collectionDisplayName || entry.collection),
        consolidatedJsonPath: consolidatedJsonPath,
        consolidatedCsvPath: consolidatedCsvPath,
        consolidatedHtmlPath: consolidatedHtmlPath,
        consolidatedXlsxPath: xlsx ? consolidatedXlsxPath : 'XLSX skipped (xlsx package not installed)',
        failedRows: executionRows.filter((row) => String(row.result || '').toLowerCase() === 'fail')
      })
    );
    return;
  }

  console.log('\nAll collection runs completed successfully.');
  finalizeRun(
    0,
    smtpConfig,
    buildAllCollectionsMailPayload(smtpConfig, {
      statusLabel: 'PASS',
      totalCollections: collectionPaths.length,
      failedCollections: failedRuns,
      totalRequests,
      totalAssertions,
      failedAssertions,
      passCount: overallResultCounts.passCount,
      failCount: overallResultCounts.failCount,
      nullDataResponses: overallDataStateCounts.nullCount,
      emptyDataResponses: overallDataStateCounts.emptyCount,
      failedCollectionNames: [],
      consolidatedJsonPath: consolidatedJsonPath,
      consolidatedCsvPath: consolidatedCsvPath,
      consolidatedHtmlPath: consolidatedHtmlPath,
      consolidatedXlsxPath: xlsx ? consolidatedXlsxPath : 'XLSX skipped (xlsx package not installed)',
      failedRows: executionRows.filter((row) => String(row.result || '').toLowerCase() === 'fail')
    })
  );
  return;
}

if (!collectionPath) {
  console.error('No collection found. Provide --collection or add a *.postman_collection.json file under collections/.');
  process.exit(1);
}

ensureFileExists(collectionPath, 'Collection');
ensureFileExists(environmentPath, 'Environment');
ensureFileExists(iterationDataPath, 'Iteration data');

console.log(`Collection: ${collectionPath}`);
if (environmentPath) {
  console.log(`Environment: ${environmentPath}`);
} else {
  console.log('Environment: none');
}
if (iterationDataPath) {
  console.log(`Iteration data: ${iterationDataPath}`);
} else {
  console.log('Iteration data: none (single ticker from environment)');
}
console.log(`Archive reports: ${archiveReports}`);

if (!fs.existsSync(reportsDir)) {
  fs.mkdirSync(reportsDir, { recursive: true });
}

newman.run(
  {
    collection: loadCollectionWithCommonHeaders(collectionPath),
    environment: environmentObject,
    iterationData,
    insecure,
    reporters: ['cli', 'htmlextra', 'junit', 'json'],
    reporter: {
      htmlextra: {
        export: reportFile,
        darkTheme: false,
        showEnvironmentData: true,
        skipEnvironmentVars: hideReportSecrets ? ['clientId', 'headerMsgId'] : [],
        skipHeaders: hideReportSecrets ? ['client_id', 'X-NW-Message-ID'] : []
      },
      junit: {
        export: junitFile
      },
      json: {
        export: jsonFile
      }
    }
  },
  (err, summary) => {
    const clientIdValue = getEnvironmentVariableValue(environmentObject, 'clientId');

    // pm.sendRequest in prerequest scripts fires the same cursor.ref twice; keep only the last.
    const rawExecutions = (summary && summary.run && Array.isArray(summary.run.executions))
      ? summary.run.executions
      : [];
    const lastIndexByCursorRef = new Map();
    rawExecutions.forEach((execution, index) => {
      const ref = execution && execution.cursor && execution.cursor.ref;
      lastIndexByCursorRef.set(ref !== undefined ? ref : index, index);
    });
    const dedupedExecutions = rawExecutions.filter((_, i) => {
      const ref = rawExecutions[i] && rawExecutions[i].cursor && rawExecutions[i].cursor.ref;
      return lastIndexByCursorRef.get(ref !== undefined ? ref : i) === i;
    });

    const executionResults = dedupedExecutions.map((execution) => {
        const responseCode = execution && execution.response ? execution.response.code : null;
        const responseStatus = execution && execution.response ? execution.response.status : null;
        const tickerFromUrl = execution
          && execution.request
          && execution.request.url
          && Array.isArray(execution.request.url.path)
          ? execution.request.url.path[4]
          : null;
        const responseDataState = detectResponseDataState(execution);

        return {
          requestName: execution && execution.item ? execution.item.name : null,
          ticker: tickerFromUrl,
          responseCode,
          responseStatus,
          responseTimeMs: execution && execution.response ? execution.response.responseTime : null,
          responseDataState,
          result: getExecutionResultStatus(responseCode, responseDataState)
        };
      });

    const runSummary = {
      timestamp: new Date().toISOString(),
      collectionPath,
      environmentPath: environmentPath || null,
      iterationDataPath: iterationDataPath || null,
      totals: summary && summary.run ? summary.run.stats : null,
      failures: summary && summary.run && summary.run.failures ? summary.run.failures.length : 0,
      executionResults,
      artifacts: {
        html: reportFile,
        junit: junitFile,
        json: jsonFile,
        csv: csvFile
      }
    };

    const runDataStateCounts = calculateDataStateCounts(executionResults);
    const runResultCounts = calculateResultCounts(executionResults);

    if (err) {
      runSummary.error = err.message;
      fs.writeFileSync(summaryFile, JSON.stringify(runSummary, null, 2));
      console.error('Newman execution failed:', err.message);
      console.error(`Summary file: ${summaryFile}`);
      finalizeRun(
        1,
        smtpConfig,
        buildSingleRunMailPayload(smtpConfig, {
          statusLabel: 'ERROR',
          collectionPath,
          environmentPath,
          iterationDataPath,
          failures: runSummary.failures,
          totals: runSummary.totals,
          passCount: runResultCounts.passCount,
          failCount: runResultCounts.failCount,
          nullDataResponses: runDataStateCounts.nullCount,
          emptyDataResponses: runDataStateCounts.emptyCount,
          summaryFilePath: summaryFile,
          htmlReportPath: reportFile,
          junitReportPath: junitFile,
          jsonReportPath: jsonFile,
          csvReportPath: csvFile,
          notes: err.message,
          failedRows: executionResults.filter((row) => String(row.result || '').toLowerCase() === 'fail')
        })
      );
      return;
    }

    fs.writeFileSync(summaryFile, JSON.stringify(runSummary, null, 2));
    fs.writeFileSync(csvFile, buildExecutionResultsCsv(executionResults));

    if (maskClientId && clientIdValue) {
      maskValueInFile(reportFile, clientIdValue, '[MASKED_CLIENT_ID]');
      maskValueInFile(junitFile, clientIdValue, '[MASKED_CLIENT_ID]');
      maskValueInFile(jsonFile, clientIdValue, '[MASKED_CLIENT_ID]');
      maskValueInFile(summaryFile, clientIdValue, '[MASKED_CLIENT_ID]');
      maskValueInFile(csvFile, clientIdValue, '[MASKED_CLIENT_ID]');
    }

    if (archiveReports) {
      if (fs.existsSync(reportFile)) {
        fs.copyFileSync(reportFile, latestReportFile);
      }
      if (fs.existsSync(junitFile)) {
        fs.copyFileSync(junitFile, latestJunitFile);
      }
      if (fs.existsSync(jsonFile)) {
        fs.copyFileSync(jsonFile, latestJsonFile);
      }
      if (fs.existsSync(summaryFile)) {
        fs.copyFileSync(summaryFile, latestSummaryFile);
      }
      if (fs.existsSync(csvFile)) {
        fs.copyFileSync(csvFile, latestCsvFile);
      }
    }

    if (executionResults.length > 0) {
      console.log('Response codes by request:');
      executionResults.forEach((result, index) => {
        const tickerLabel = result.ticker || 'N/A';
        const codeLabel = result.responseCode || 'N/A';
        const statusLabel = result.responseStatus || 'N/A';
        const timeLabel = typeof result.responseTimeMs === 'number' ? `${result.responseTimeMs}ms` : 'N/A';
        const dataStateLabel = result.responseDataState || 'N/A';
        console.log(`${index + 1}. ${result.requestName} | ticker=${tickerLabel} | code=${codeLabel} ${statusLabel} | time=${timeLabel} | data=${dataStateLabel}`);
      });
    }

    if (summary.run.failures && summary.run.failures.length > 0) {
      console.error(`Run completed with ${summary.run.failures.length} failure(s).`);
      console.error(`Insecure TLS mode: ${insecure}`);
      console.error(`Mask clientId in artifacts: ${maskClientId}`);
      console.error(`Hide report secrets: ${hideReportSecrets}`);
      console.error(`Archive reports: ${archiveReports}`);
      console.error(`HTML report: ${latestReportFile}`);
      console.error(`JUnit report: ${latestJunitFile}`);
      console.error(`JSON report: ${latestJsonFile}`);
      console.error(`Summary file: ${latestSummaryFile}`);
      console.error(`CSV response file: ${latestCsvFile}`);
      if (archiveReports) {
        console.error(`Archived HTML report: ${reportFile}`);
        console.error(`Archived JUnit report: ${junitFile}`);
        console.error(`Archived JSON report: ${jsonFile}`);
        console.error(`Archived summary file: ${summaryFile}`);
        console.error(`Archived CSV response file: ${csvFile}`);
      }
      finalizeRun(
        1,
        smtpConfig,
        buildSingleRunMailPayload(smtpConfig, {
          statusLabel: 'FAIL',
          collectionPath,
          environmentPath,
          iterationDataPath,
          failures: runSummary.failures,
          totals: runSummary.totals,
          passCount: runResultCounts.passCount,
          failCount: runResultCounts.failCount,
          nullDataResponses: runDataStateCounts.nullCount,
          emptyDataResponses: runDataStateCounts.emptyCount,
          summaryFilePath: latestSummaryFile,
          htmlReportPath: latestReportFile,
          junitReportPath: latestJunitFile,
          jsonReportPath: latestJsonFile,
          csvReportPath: latestCsvFile,
          notes: 'One or more assertions failed.',
          failedRows: executionResults.filter((row) => String(row.result || '').toLowerCase() === 'fail')
        })
      );
      return;
    }

    console.log('Run completed successfully.');
    console.log(`Insecure TLS mode: ${insecure}`);
    console.log(`Mask clientId in artifacts: ${maskClientId}`);
    console.log(`Hide report secrets: ${hideReportSecrets}`);
    console.log(`Archive reports: ${archiveReports}`);
    console.log(`HTML report: ${latestReportFile}`);
    console.log(`JUnit report: ${latestJunitFile}`);
    console.log(`JSON report: ${latestJsonFile}`);
    console.log(`Summary file: ${latestSummaryFile}`);
    console.log(`CSV response file: ${latestCsvFile}`);
    if (archiveReports) {
      console.log(`Archived HTML report: ${reportFile}`);
      console.log(`Archived JUnit report: ${junitFile}`);
      console.log(`Archived JSON report: ${jsonFile}`);
      console.log(`Archived summary file: ${summaryFile}`);
      console.log(`Archived CSV response file: ${csvFile}`);
    }

    finalizeRun(
      0,
      smtpConfig,
      buildSingleRunMailPayload(smtpConfig, {
        statusLabel: 'PASS',
        collectionPath,
        environmentPath,
        iterationDataPath,
        failures: runSummary.failures,
        totals: runSummary.totals,
        passCount: runResultCounts.passCount,
        failCount: runResultCounts.failCount,
        nullDataResponses: runDataStateCounts.nullCount,
        emptyDataResponses: runDataStateCounts.emptyCount,
        summaryFilePath: latestSummaryFile,
        htmlReportPath: latestReportFile,
        junitReportPath: latestJunitFile,
        jsonReportPath: latestJsonFile,
        csvReportPath: latestCsvFile,
        notes: 'Run completed successfully.',
        failedRows: executionResults.filter((row) => String(row.result || '').toLowerCase() === 'fail')
      })
    );
  }
);
