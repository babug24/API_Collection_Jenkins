# Angular_NF_API_Testing - Task Scheduler Setup Guide

## Quick Setup (Copy-Paste Ready)

### Step 1: Manual Test the .bat File
```powershell
cd C:\Cypress_Automation_Worldwide\Angular_NF_API_Testing
.\run-fund-profile-api.bat
```

Expected output:
- Console showing execution progress
- Log file saved to: `%USERPROFILE%\AppData\Local\Temp\Angular_NF_API_Testing_*.log`
- HTML + JSON reports in: `C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing\reports\`

---

## Task Scheduler Setup

### Option 1: Using GUI (Easiest)

1. **Open Task Scheduler**
   - Press `Win + R` → type `taskschd.msc` → Enter
   - Or: Search for "Task Scheduler" in Windows

2. **Create New Task**
   - Right-click "Task Scheduler Library" → "Create Task"
   - Name: `Angular_NF_API_Testing - Fund Profile API`
   - Check: ☑ "Run with highest privileges"

3. **Triggers Tab**
   - Click "New..."
   - Set schedule (examples):
     - **Daily at 2 AM:** Begin the task: Daily → 2:00:00 AM
     - **Weekly Monday 8 AM:** Begin the task: Weekly → Monday → 8:00:00 AM
     - **Every 12 hours:** Begin the task: Recurring → 12 hours
   - Click OK

4. **Actions Tab**
   - Click "New..."
   - Program/script: `C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing\run-fund-profile-api.bat`
   - Start in: `C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing`
   - Click OK

5. **Conditions Tab** (Optional)
   - ☐ Uncheck "Stop if computer switches to battery power" (if laptop)
   - ☐ Uncheck "Stop if running on batteries"
   - ☑ Check "Wake the computer to run this task"

6. **Settings Tab**
   - ☑ "Allow task to be run on demand"
   - ☑ "Run task as soon as possible after a scheduled start is missed"
   - Dropdown: "If the task fails, restart every: 1 hour"
   - "Stop the task if it runs longer than: 2 hours"
   - Click OK → Enter Windows credentials if prompted

---

### Option 2: Using PowerShell (Automated)

**Run as Administrator:**

```powershell
# Define task parameters
$TaskName = "Angular_NF_API_Testing - Fund Profile API"
$BatchPath = "C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing\run-fund-profile-api.bat"
$WorkDir = "C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing"

# Daily at 2:00 AM
$Trigger = New-ScheduledTaskTrigger -Daily -At 2:00AM

# OR: Weekly Monday at 8:00 AM (uncomment to use instead)
# $Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 8:00AM

# OR: Every 12 hours (uncomment to use instead)
# $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Hours 12) -RepetitionDuration (New-TimeSpan -Days 36500)

# Action: Run the batch file
$Action = New-ScheduledTaskAction -Execute $BatchPath -WorkingDirectory $WorkDir

# Settings
$Settings = New-ScheduledTaskSettingsSet `
  -AllowStartIfOnBatteries `
  -DontStopIfGoingOnBatteries `
  -StartWhenAvailable `
  -RunOnlyIfNetworkAvailable `
  -MultipleInstances IgnoreNew

# Create or update the task
$ExistingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($ExistingTask) {
    Set-ScheduledTask -TaskName $TaskName -Trigger $Trigger -Action $Action -Settings $Settings
    Write-Host "✓ Task updated: $TaskName"
} else {
    Register-ScheduledTask -TaskName $TaskName `
      -Trigger $Trigger `
      -Action $Action `
      -Settings $Settings `
      -RunLevel Highest
    Write-Host "✓ Task created: $TaskName"
}

# Verify
Get-ScheduledTask -TaskName $TaskName | Select-Object TaskName, State
Get-ScheduledTaskInfo -TaskName $TaskName
```

---

## Usage

### View Scheduled Task
```powershell
Get-ScheduledTask -TaskName "Angular_NF_API_Testing*"
```

### Run Task Manually (Immediate Execution)
```powershell
Start-ScheduledTask -TaskName "Angular_NF_API_Testing - Fund Profile API"
```

### Check Last Execution
```powershell
Get-ScheduledTaskInfo -TaskName "Angular_NF_API_Testing - Fund Profile API"
```

### View Execution Log
```powershell
# Find most recent log
Get-Item "$env:APPDATA\..\Local\Temp\Angular_NF_API_Testing_*.log" | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | % { notepad.exe $_.FullName }

# Or manually:
# C:\Users\[YourUsername]\AppData\Local\Temp\Angular_NF_API_Testing_*.log
```

### Delete Task
```powershell
Unregister-ScheduledTask -TaskName "Angular_NF_API_Testing - Fund Profile API" -Confirm:$false
```

---

## Output Locations

After each execution, you'll find:

1. **Execution Log**
   - Location: `%USERPROFILE%\AppData\Local\Temp\Angular_NF_API_Testing_YYYY-MM-DD_HH-MM.log`
   - Contains: Start time, execution details, exit code, end time

2. **HTML Report**
   - Location: `C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing\reports\fund-profile-api-report-YYYY-MM-DD_HH-MM.html`
   - View in browser

3. **JSON Report**
   - Location: `C:\Cypress_Automation_Nationwide\Angular_NF_API_Testing\reports\fund-profile-api-report-YYYY-MM-DD_HH-MM.json`
   - For programmatic processing

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Task won't run | Check "Run with highest privileges" ☑ |
| "Could not find file" error | Verify batch file path in Task Scheduler Action |
| npx command not found | Ensure npm/Node.js PATH includes C:\Program Files\nodejs |
| Reports not generated | Check log file in %TEMP% folder |
| Task runs but exits immediately | Batch file has error; test manually first |

---

## Example Schedules

```
Daily: 2:00 AM (overnight runs)
Weekly: Monday 8:00 AM (start-of-week validation)
Every 12 hours: Continuous monitoring
Every 24 hours: Standard daily automation
```

Choose based on your testing needs!
